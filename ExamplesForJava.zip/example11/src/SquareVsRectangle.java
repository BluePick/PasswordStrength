public class SquareVsRectangle {

	/**
	 * Test the Square and Rectangle classes for correctness. Is Square a
	 * subtype of Rectangle?
	 * 
	 * @param args
	 *            (no arguments needed by main)
	 */
	public static void main(String[] args) {

		// let us create a square
		Square s = new Square(10);

		// let us test the area method
		System.out.println("The area of the square is " + s.getArea()); // we
																		// should
																		// see
																		// 100

		// Square is a subclass of Rectangle, so Java permits the following:
		Rectangle r = s;

		// let us test the area method
		// we should get 100 again
		// and we cannot change the objects so immutable squares do behave like
		// immutable rectangles
		System.out.println("The area of the rectangle is " + r.getArea());

	}

}
