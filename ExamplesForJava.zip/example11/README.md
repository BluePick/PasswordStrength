Example 11: Immutable Squares and Rectangles
===

Immutable Squares are subtypes of Immutable Rectangles.

The source of grief in the subclassing vs. subtyping issue in [Example 10](https://github.com/EECE-210/example10) is the fact that `Rectangle` and `Square` are mutable. We can eliminate this problem by making the two classes **immutable**. To do this, we remove all the setter methods (methods that set/change fields within the objects) **and**, in this example, there is no other mechanism to change the objects indirectly. Voila! `Square` is now a subtype of `Rectangle.`

Examples 10 and 11 illustrate the need for care when subclassing. Good software developers use subclasses that are also subtypes.