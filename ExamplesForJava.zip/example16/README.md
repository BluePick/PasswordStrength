Example 16: Concurrency and the Fibonacci Server
===


This example illustrates the use of concurrent threads to process multiple requests from a server. The server is a process that receives a request to compute the n<sup>th</sup> Fibonacci number, which it then computes and returns to the requestor.