Example 13: Concurrency and Data Races
===


The programs in this example demonstrate how data races may occur. The reading that goes with this example can be found here: [http://gsathish.github.io/eece210/m-Concurrency/](http://gsathish.github.io/eece210/m-Concurrency/). 

To experiment with the examples and see data races, look at the code in `src/beforeclass`. Vary the number of trials/iterations and you should encounter data races.

