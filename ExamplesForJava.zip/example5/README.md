Example 5: Objects, References, and Call-by-Value
========


This is a simple example to illustrate how Java handles objects, and in particular how the “value” of an object is the memory location or reference to that object.

**Investigate:** What does aliasing mean in Java?

### Related reading
* [Creating objects in Java](http://docs.oracle.com/javase/tutorial/java/javaOO/objectcreation.html)

### Source code excerpts from this example

The `main( )` method is as follows:
```java
    /**
     * This method illustrates how Java handles objects and aliasing.
     * 
     * @param args
     *            No arguments needed.
     */
    public static void main(String[] args) {
        Point p1 = new Point(5, 5);

        // What do you think will happen here?
        System.out.println("p1: " + p1);
        // You should see the address of the object p1.
        // This illustrates that Java stores a reference to the actual object in
        // the variable associated with that object.

        // Now let us perform an assignment.
        Point p2 = p1;
        System.out.println("p2: " + p2);
        // We should have seen the same output as earlier.

        // Let us now print the x coordinate of p1.
        System.out.println("x-coordinate of p1: " + p1.get_xCoord());

        // Let us now print the x coordinate of p2.
        System.out.println("x-coordinate of p2: " + p2.get_xCoord());

        // Let us now change p2.
        p2.set_xCoord(10);

        // Let us try printing the x coordinate of p1 once again.
        System.out.println("x-coordinate of p1: " + p1.get_xCoord());
        // We should see 10 now.
        // This illustrates that p1 and p2 refer to the same object.
        // We can change this object through p1 and p2.
        // This is called aliasing.

        // Let us now create a new Point and let p1 refer to it.
        p1 = new Point(7, 7);

        // Let us print the y coordinates of p1 and p2.
        System.out.println("y-coordinate of p1: " + p1.get_yCoord());
        System.out.println("y-coordinate of p2: " + p2.get_yCoord());
        // They should have been 7 and 5, respectively.
        // This is because p1 and p2 do not refer to the same object any more.

        // Let us confirm the last statement by printing p1.
        System.out.println("p1: " + p1);
        // We should get a different address from earlier!

        // Let us test the Manhattan distance method.
        // This will also illustrate Java's call-by-value semantics.
        System.out.println("The Manhattan distance between p1 and p2 is: "
                + p1.manhattanDistance(p2));

        // Let us print the y coordinates of p2.
        System.out.println("y-coordinate of p2: " + p2.get_yCoord());
        // Looks like p2 changed during the call to manhattanDistance!

    }

}
```

It is also useful to look at the `manhattanDistance( )` method within the class `Point`:
```java
/**
     * This method returns the Manhattan distance between this point and a
     * different point.
     * 
     * @param p
     *            not null.
     * @return the Manhattan distance between this point and p.
     */
    public int manhattanDistance(Point p) {
        // print the object that was passed
        System.out.println("The object passed as argument is " + p);

        // compute the Manhattan distance
        int dist = Math.abs(p.get_xCoord() - xCoord)
                + Math.abs(p.get_yCoord() - yCoord);
        
        // Let us change p.
        p.set_yCoord( 11 );
        
        return dist;
    }
```
