/**
 * 
 * This is a class for representing points on the 2-dimensional Cartesian plane.
 * 
 * @author Sathish Gopalakrishnan
 * 
 */
public class Point {

    // we need two fields to keep track of the x and y coordinates.
    private int xCoord;
    private int yCoord;

    /**
     * Constructor that creates a new Point given x and y coordinates.
     * 
     * @param x
     *            x-coordinate of point
     * @param y
     *            y-coordinate of point
     */
    public Point(int x, int y) {
        xCoord = x;
        yCoord = y;
    }

    /**
     * Get the x-coordinate of the point.
     * 
     * @return the x-coordinate of the point.
     */
    public int get_xCoord() {
        return xCoord;
    }

    /**
     * Get the y-coordinate of the point.
     * 
     * @return the y-coordinate of the point.
     */
    public int get_yCoord() {
        return yCoord;
    }

    /**
     * Set the x-coordinate of the point.
     */
    public void set_xCoord(int x) {
        xCoord = x;
    }

    /**
     * Set the x-coordinate of the point.
     */
    public void set_yCoord(int y) {
        yCoord = y;
    }

    /**
     * This method returns the Manhattan distance between this point and a
     * different point.
     * 
     * @param p
     *            not null.
     * @return the Manhattan distance between this point and p.
     */
    public int manhattanDistance(Point p) {
        // print the object that was passed
        System.out.println("The object passed as argument is " + p);

        // compute the Manhattan distance
        int dist = Math.abs(p.get_xCoord() - xCoord)
                + Math.abs(p.get_yCoord() - yCoord);
        
        // Let us change p.
        p.set_yCoord( 11 );
        
        return dist;
    }

}
