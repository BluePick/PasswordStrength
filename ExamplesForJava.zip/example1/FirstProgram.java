
public class FirstProgram {

	// Let us print two strings.
	public static void main(String[] args) {
		
		System.out.println( "Welcome to EECE 210!" );
		System.out.println( "Was that not easy?" );
		

	}

}
