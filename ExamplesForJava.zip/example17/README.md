Example 17: GUIs
=========


**Read:** Introduction to [GUIs](http://gsathish.github.io/eece210/r-GUIs/)

### About this example

This example illustrates how one can create a simple graphical user interface. This example also illustrates the use of the model-view-controller design pattern.

To get started, you can run `gui/MainWindow`, which contains the method `main()`. To see how to control the response to certain events, replace the call to `thrashForeground()` in `thrashWithSelectedFriend()` in the file `gui/WizardView.java` with a call to `thrashBackground()`.