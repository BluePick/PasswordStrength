Example 15: Thread Safety
===

Examples of confinement and using thread-safe collections.


Some of the code here uses network sockets to provide communication between processes on different machines. Network communication, however, is not the focus of this example.

For this example, you should example the provided code and reason about the following questions.

Are the following variables/objects thread-confined?

+ `SocialServer.friendsOf`
+ `RiskyStatic.cache`
+ `graph` in `SocialServer.makeFriendsGraph`
+ `socket` in `SocialServer.serve`
+ `Midi.midi`

Are the following variables/objects strongly immutable?

+ `SocialServer.PORT`
+ `RiskyInstance`
+ `SocialServer.friendsOf`

Are the following variables/objects safe for concurrency?

+ `graph` in `SocialServer.makeFriendsGraph`
+ the `Map` returned from `SocialServer.makeFriendsGraph`
+ `Midi`
+ `cache` in `RiskyStatic` or `RiskyInstance`

Is the following operation safe in a concurrent setting?
+ iteration over `friends` in `SocialServer.handle`
